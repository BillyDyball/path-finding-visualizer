self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "777d2b5db830f5f4fd74c355b86a7646",
    "url": "./index.html"
  },
  {
    "revision": "2b0b6668a2507e76c117",
    "url": "./static/css/2.d9ad5f5c.chunk.css"
  },
  {
    "revision": "72925492cddafb244f0a",
    "url": "./static/css/main.304759de.chunk.css"
  },
  {
    "revision": "2b0b6668a2507e76c117",
    "url": "./static/js/2.ec90c382.chunk.js"
  },
  {
    "revision": "5ac48c47bb3912b14c2d8de4f56d5ae8",
    "url": "./static/js/2.ec90c382.chunk.js.LICENSE.txt"
  },
  {
    "revision": "72925492cddafb244f0a",
    "url": "./static/js/main.b9289b62.chunk.js"
  },
  {
    "revision": "24771881cb892f5789ef",
    "url": "./static/js/runtime-main.741f19c0.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "./static/media/logo.5d5d9eef.svg"
  }
]);